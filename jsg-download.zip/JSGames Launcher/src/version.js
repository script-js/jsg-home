var dlver = "3"
// add to home -> <script src="https://script-js.github.io/jsg-home/dlver.js"></script><script src="version.js"></script>